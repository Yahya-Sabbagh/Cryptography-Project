package com.example.Cryptography.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CryptographyProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
