package com.example.Cryptography.Project.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.Cryptography.Project.aes.algorithm.AesAlgorithm;

@RestController
public class AesController {
	
	private AesAlgorithm aes =new AesAlgorithm("secretKey1234567");
	
	String message = "A Very Important Message!";

	@GetMapping("/getMessage/key/{key}")
	public String getMessage(@PathVariable String key) {
		try {
			String encryptedMessage=aes.encryptMessage(message);
			System.out.println("Encrypted message: "+encryptedMessage);
			
			if(!key.equals("secretKey1234567"))
			   return encryptedMessage;
			
			return aes.decryptMessage(encryptedMessage);
					
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "something went wrong";	
	}
}
