package com.example.Cryptography.Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CryptographyProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CryptographyProjectApplication.class, args);
	}

}
