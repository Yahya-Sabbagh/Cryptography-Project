package com.example.Cryptography.Project.aes.algorithm;
import java.security.Key;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class AesAlgorithm {

	private static final String ALGORITHM ="AES";
	private byte[] keyValue;
	
	public AesAlgorithm(String key) {
		this.keyValue = key.getBytes();
	}
	

	//encryption method
	public String encryptMessage(String message) throws Exception{
		Key key =generateKey();
		Cipher cipher =Cipher.getInstance(ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte [] encMessage = cipher.doFinal(message.getBytes());
		String encryptherMessage = Base64.getEncoder().encodeToString(encMessage);
		return encryptherMessage;
		
	}
	
	//decryption method
	public String decryptMessage (String encryptherMessage) throws Exception{
		Key key =generateKey();
		Cipher cipher =Cipher.getInstance(ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE, key);
		byte[] decodedMessage = Base64.getDecoder().decode(encryptherMessage);
		byte[] decMessage = cipher.doFinal(decodedMessage); 
		String decryptedMessage =new String(decMessage);
		return decryptedMessage;
		
	}
	
	//key generator
	private Key generateKey() throws Exception{
		return new SecretKeySpec(keyValue,ALGORITHM);
	
	}
}
